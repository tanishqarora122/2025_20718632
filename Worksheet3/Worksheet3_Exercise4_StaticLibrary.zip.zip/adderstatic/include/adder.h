#ifndef ADDER_H
#define ADDER_H

int add(int a, int b);

#endif
